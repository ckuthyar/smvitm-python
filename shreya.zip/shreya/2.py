num1=5.1
print(int(num1))
num2=5.0
print(int(num2))
