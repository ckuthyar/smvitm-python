f1=open("GoldMedal.txt", "r")
names=[]
english=[]
toppers_english=[]
maths=[]
toppers_maths=[]
physics=[]
toppers_physics=[]
chemistry=[]
toppers_chemistry=[]
biology=[]
toppers_biology=[]
allsubjects=[]
gold_medalist=[]

for i in range(0,26,1):    
    info1=f1.readline()
    list1=info1.split(",")
    names.append(list1[0])
    list2=list1[3].split(":")
    english.append(int(list2[1]))
    list2=list1[4].split(":")
    maths.append(int(list2[1]))
    list2=list1[5].split(":")
    physics.append(int(list2[1]))
    list2=list1[6].split(":")
    chemistry.append(int(list2[1]))
    list2=list1[7].split(":")
    biology.append(int(list2[1]))
    allsubjects.append(english[i]+maths[i]+physics[i]+chemistry[i]+biology[i])

print(names)
print("English",english)
print("Maths",maths)
print("Physics",physics)
print("Chemistry",chemistry)
print("Biology",biology)

print("Total",allsubjects)
    
maxEnglish=max(english)
maxMaths=max(maths)
maxPhysics=max(physics)
maxChemistry=max(chemistry)
maxBiology=max(biology)
maxAllSubjects=max(allsubjects)

for i in range(0,26,1):
    if english[i]==maxEnglish:
        toppers_english.append(names[i])
    if maths[i]==maxMaths:
        toppers_maths.append(names[i])
    if physics[i]==maxPhysics:
        toppers_physics.append(names[i])
    if chemistry[i]==maxChemistry:
        toppers_chemistry.append(names[i])
    if biology[i]==maxBiology:
        toppers_biology.append(names[i])
    if allsubjects[i]==maxAllSubjects:
        gold_medalist.append(names[i])

print(toppers_english, " - toppers in English with marks", maxEnglish)
print(toppers_maths, "- toppers in Maths with marks", maxMaths)
print(toppers_physics, "- toppers in Physics with marks", maxPhysics)
print(toppers_chemistry, "- toppers in Chemistry with marks", maxChemistry)
print(toppers_biology, "- toppers in Biology with marks", maxBiology)
print(gold_medalist, "- Gold Medalist with highest marks", maxAllSubjects)



    
