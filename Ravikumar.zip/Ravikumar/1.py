for j in range(3,6,1):
    
    for i in range(1,11,1):
        print(j,i,j*i)
    print()
