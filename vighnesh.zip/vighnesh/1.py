s1="vighnesh is a good boy"
s2=""
len1=len(s1)
print(len1)
for i in range(0,len1,1):
    s2=s2+s1[len1-1-i]


print(s2)
