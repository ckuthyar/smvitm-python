import mod_perm as pm

pm.perm3("EAT")
pm.perm3("TRY")
pm.perm3("ASK")

pm.perm4("FAST")
pm.perm4("ABCD")
pm.perm4("PQRS")
