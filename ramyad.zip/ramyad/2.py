list1=[]
list2=[]
list3=[]
for i in range(1,4,1):
    list1.append(i**2)
    list2.append(i**3)
    list3.append(i**4)
print(list1)
print(list2)
print(list3)
