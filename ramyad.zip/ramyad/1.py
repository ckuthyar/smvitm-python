for i in range(0,10,1):
    print(i**5)
