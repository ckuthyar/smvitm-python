for i in range(1,4,1):
    print(3,i,3*i)
for i in range(4,11,1):
    print(4,i,4*i)
