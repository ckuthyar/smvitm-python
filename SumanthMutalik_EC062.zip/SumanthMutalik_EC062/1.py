for i in range(0,12,1):
    angle1=(90+i*30-i*2.5)
    print(angle1%360)
print()
for i in range(0,12,1):
    angle1=(90+i*30-i*2.5)
    print(angle1%360)
